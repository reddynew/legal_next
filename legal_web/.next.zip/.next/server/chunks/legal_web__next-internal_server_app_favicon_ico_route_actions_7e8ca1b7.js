module.exports=[707011,(e,o,d)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_favicon_ico_route_actions_7e8ca1b7.js.map