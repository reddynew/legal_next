module.exports=[109849,(a,b,c)=>{}];

//# sourceMappingURL=30af3_web__next-internal_server_app_services_Legal-consultation_page_actions_9188bafa.js.map