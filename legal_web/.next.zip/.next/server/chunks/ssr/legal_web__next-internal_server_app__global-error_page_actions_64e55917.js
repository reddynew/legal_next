module.exports=[284087,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app__global-error_page_actions_64e55917.js.map