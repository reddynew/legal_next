module.exports=[403509,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_register_page_actions_02520510.js.map