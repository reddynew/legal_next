module.exports=[904556,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_PrivacyPolicy_page_actions_d7ea5533.js.map