module.exports=[180666,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_Payments_page_actions_a3f70796.js.map