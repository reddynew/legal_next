module.exports=[264863,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_Disclaimers_page_actions_26e187fa.js.map