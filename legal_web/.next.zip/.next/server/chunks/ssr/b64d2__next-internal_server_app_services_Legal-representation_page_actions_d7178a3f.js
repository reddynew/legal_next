module.exports=[294888,(a,b,c)=>{}];

//# sourceMappingURL=b64d2__next-internal_server_app_services_Legal-representation_page_actions_d7178a3f.js.map