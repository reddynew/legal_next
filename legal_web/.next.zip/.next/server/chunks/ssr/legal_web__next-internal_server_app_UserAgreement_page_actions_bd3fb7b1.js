module.exports=[310228,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_UserAgreement_page_actions_bd3fb7b1.js.map