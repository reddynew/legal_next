module.exports=[655423,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_signup_page_actions_54ceeb1a.js.map