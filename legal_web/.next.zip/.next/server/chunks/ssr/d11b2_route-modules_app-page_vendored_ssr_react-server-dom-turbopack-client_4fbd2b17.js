module.exports=[186182,(a,b,c)=>{"use strict";b.exports=a.r(624452).vendored["react-ssr"].ReactServerDOMTurbopackClient}];

//# sourceMappingURL=d11b2_route-modules_app-page_vendored_ssr_react-server-dom-turbopack-client_4fbd2b17.js.map