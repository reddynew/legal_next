module.exports=[435388,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_blog_page_actions_c8a18666.js.map