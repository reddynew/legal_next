module.exports=[752135,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_PersonalDashboard_page_actions_c33b580f.js.map