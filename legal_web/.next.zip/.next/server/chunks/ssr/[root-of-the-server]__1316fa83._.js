module.exports=[193695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},478031,a=>{a.n(a.i(912140))},110789,a=>{a.n(a.i(849736))},558159,a=>{a.n(a.i(736205))},305786,a=>{a.n(a.i(620961))},388548,a=>{a.n(a.i(605853))},389331,a=>{"use strict";let b=[{slug:"nri-legal-help",title:"Complete Guide to NRI Legal Help in India",excerpt:"Everything NRIs must know about documentation, disputes, and property issues.",image:"https://jplawsuvidha.com/og_logo.jpg",content:`
      <p>NRIs often face challenges with property disputes, documentation, 
      and legal representation in India. In this guide, we cover the most 
      important things you need to know...</p>
    `},{slug:"property-disputes-india",title:"How to Handle Property Disputes in India",excerpt:"A practical guide for individuals dealing with land and property issues.",image:"https://jplawsuvidha.com/og_logo.jpg",content:`
      <p>Property disputes are extremely common in India. Here are the 
      key steps involved in resolving them...</p>
    `},{slug:"register-fir-india",title:"How to Register an FIR in India",excerpt:"Step-by-step method to file an FIR legally and effectively.",image:"https://jplawsuvidha.com/og_logo.jpg",content:`
      <p>Understanding how to file an FIR is important for anyone involved 
      in a criminal matter. Here’s what you must know...</p>
    `}];a.s(["blogPosts",0,b])},287608,a=>{"use strict";var b=a.i(901402),c=a.i(572473),d=a.i(389331);function e(){return(0,b.jsx)(b.Fragment,{children:d.blogPosts.map(a=>(0,b.jsxs)("div",{children:[(0,b.jsx)("h2",{children:a.title}),(0,b.jsx)(c.default,{href:`/blog/${a.slug}`,children:"Read"})]},a.slug))})}function f(){return(0,b.jsxs)("div",{children:[(0,b.jsx)("h1",{children:"Blog"}),(0,b.jsx)(e,{})]})}a.s(["default",()=>f],287608)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1316fa83._.js.map