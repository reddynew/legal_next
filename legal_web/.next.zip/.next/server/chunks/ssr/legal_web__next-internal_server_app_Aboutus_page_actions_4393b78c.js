module.exports=[630617,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_Aboutus_page_actions_4393b78c.js.map