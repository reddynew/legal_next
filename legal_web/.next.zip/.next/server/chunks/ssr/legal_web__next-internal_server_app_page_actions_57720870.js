module.exports=[753579,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_page_actions_57720870.js.map