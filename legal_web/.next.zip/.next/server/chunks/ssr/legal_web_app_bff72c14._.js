module.exports=[357747,a=>{a.v("/_next/static/media/favicon.7181a4ca.ico")},878431,a=>{"use strict";let b={src:a.i(357747).default,width:500,height:500};a.s(["default",0,b])}];

//# sourceMappingURL=legal_web_app_bff72c14._.js.map