module.exports=[691882,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_Nriservices_page_actions_29069dcf.js.map