module.exports=[900459,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_profile_page_actions_e0d9e2a6.js.map