module.exports=[46769,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_blog_%5Bslug%5D_page_actions_856a3b91.js.map