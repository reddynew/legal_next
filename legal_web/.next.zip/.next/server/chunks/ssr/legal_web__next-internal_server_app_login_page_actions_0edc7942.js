module.exports=[977190,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app_login_page_actions_0edc7942.js.map