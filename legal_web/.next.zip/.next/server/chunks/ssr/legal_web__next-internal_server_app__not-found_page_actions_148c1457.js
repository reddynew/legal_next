module.exports=[264129,(a,b,c)=>{}];

//# sourceMappingURL=legal_web__next-internal_server_app__not-found_page_actions_148c1457.js.map