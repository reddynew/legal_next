var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__80b0d710._.js")
R.c("server/chunks/legal_web__next-internal_server_app_favicon_ico_route_actions_7e8ca1b7.js")
R.m(765833)
module.exports=R.m(765833).exports
