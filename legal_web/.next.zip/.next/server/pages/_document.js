var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__28c8c1af._.js")
R.c("server/chunks/ssr/[root-of-the-server]__7bb0ff94._.js")
R.m(333864)
module.exports=R.m(333864).exports
