globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/Expertise": [
      "static/chunks/9bbad47a6b9a8074.js",
      "static/chunks/0342300ac7097212.js",
      "static/chunks/d807be332f75b2e8.js",
      "static/chunks/fc5acf78d5947251.js",
      "static/chunks/c1ca3137bd8b094a.css",
      "static/chunks/turbopack-ec875c9e10bd57f8.js"
    ],
    "/Services": [
      "static/chunks/9bbad47a6b9a8074.js",
      "static/chunks/f0b2251633810ab2.js",
      "static/chunks/fc5acf78d5947251.js",
      "static/chunks/37d3f8c4c1f302b6.js",
      "static/chunks/c1ca3137bd8b094a.css",
      "static/chunks/turbopack-c8622183d2596d80.js"
    ],
    "/_app": [
      "static/chunks/e3dfa8291877e303.js",
      "static/chunks/fc5acf78d5947251.js",
      "static/chunks/turbopack-1d7554173158acbd.js"
    ],
    "/_error": [
      "static/chunks/17f561f149affde0.js",
      "static/chunks/fc5acf78d5947251.js",
      "static/chunks/turbopack-7ef1db78c8ed99a7.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b1cf2d459d321a59.js",
    "static/chunks/0fc35e04c1f43441.js",
    "static/chunks/9db06529aac99873.js",
    "static/chunks/c0d141cccf6f6a99.js",
    "static/chunks/5ce40cfb64cd0147.js",
    "static/chunks/turbopack-5c86e3ee7a396fab.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];