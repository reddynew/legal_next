__turbopack_load_page_chunks__("/Expertise", [
  "static/chunks/9bbad47a6b9a8074.js",
  "static/chunks/0342300ac7097212.js",
  "static/chunks/d807be332f75b2e8.js",
  "static/chunks/fc5acf78d5947251.js",
  "static/chunks/c1ca3137bd8b094a.css",
  "static/chunks/turbopack-ec875c9e10bd57f8.js"
])
