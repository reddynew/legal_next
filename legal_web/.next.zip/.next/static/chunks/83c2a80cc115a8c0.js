__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e3dfa8291877e303.js",
  "static/chunks/fc5acf78d5947251.js",
  "static/chunks/turbopack-1d7554173158acbd.js"
])
