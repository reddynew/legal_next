__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17f561f149affde0.js",
  "static/chunks/fc5acf78d5947251.js",
  "static/chunks/turbopack-7ef1db78c8ed99a7.js"
])
