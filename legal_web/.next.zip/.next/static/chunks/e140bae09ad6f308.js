__turbopack_load_page_chunks__("/Services", [
  "static/chunks/9bbad47a6b9a8074.js",
  "static/chunks/f0b2251633810ab2.js",
  "static/chunks/fc5acf78d5947251.js",
  "static/chunks/37d3f8c4c1f302b6.js",
  "static/chunks/c1ca3137bd8b094a.css",
  "static/chunks/turbopack-c8622183d2596d80.js"
])
