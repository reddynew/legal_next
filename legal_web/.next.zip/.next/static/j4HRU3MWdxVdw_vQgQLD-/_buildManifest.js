self.__BUILD_MANIFEST = {
  "/Expertise": [
    "static/chunks/e98ffbbc14fc114d.js"
  ],
  "/Services": [
    "static/chunks/e140bae09ad6f308.js"
  ],
  "/_error": [
    "static/chunks/1cd4e7fec6888f76.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/Expertise",
    "/Services",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()