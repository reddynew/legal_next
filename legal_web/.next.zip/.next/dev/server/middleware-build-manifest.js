globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/08594_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8c046bb4._.js",
    "static/chunks/08594_next_dist_compiled_react-dom_81378d89._.js",
    "static/chunks/08594_next_dist_compiled_react-server-dom-turbopack_03e11fbd._.js",
    "static/chunks/08594_next_dist_compiled_next-devtools_index_43e3090a.js",
    "static/chunks/08594_next_dist_compiled_72d09ec6._.js",
    "static/chunks/08594_next_dist_client_4da61896._.js",
    "static/chunks/08594_next_dist_89660b38._.js",
    "static/chunks/08594_@swc_helpers_cjs_e99ffcc7._.js",
    "static/chunks/legal_web_a0ff3932._.js",
    "static/chunks/turbopack-legal_web_84b2477e._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];