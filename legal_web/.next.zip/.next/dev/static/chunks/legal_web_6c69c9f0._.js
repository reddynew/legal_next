(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/legal_web/context/LoginContext.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const AuthProvider = ({ children })=>{
    _s();
    const [login, setLogin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [id, setId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('123');
    const [name, setName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('123');
    // const userid=1234
    // const username='jp'
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            const validateLogin = {
                "AuthProvider.useEffect.validateLogin": async ()=>{
                    try {
                        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('https://backend.com.jplawsuvidha.com/', {
                            withCredentials: true
                        });
                        if (res.status === 200 && res.data?.user) {
                            // console.log("Auth Success:", res.data);
                            setLogin(true);
                            setId(res.data.user.email);
                            setName(res.data.user.name);
                        } else {
                            console.warn("Auth failed - invalid data", res.data);
                            setLogin(false);
                        }
                    } catch (err) {
                        console.error("Auth Failed:", err.message);
                        setLogin(true);
                    } finally{
                        setLoading(false);
                    }
                }
            }["AuthProvider.useEffect.validateLogin"];
            validateLogin();
        }
    }["AuthProvider.useEffect"], []);
    const loginUser = async (email, password)=>{
        try {
            setLoading(true);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('http://localhost:3001/api/login', {
                email,
                password
            }, {
                withCredentials: true
            });
            // console.log("Login Successful:", res.data);
            if (res.data.status === 'success' || res.data.status === 'first_time') {
                setLogin(true);
                localStorage.setItem('atoken', res.data.token);
                // Update user state based on the login response
                setId(res.data.data.email);
                // console.log('user email is',res.data.data.email)
                setName(res.data.data.name);
            // This ensures the validate call will now succeed
            // You can make a second call to validate here if needed, or simply trust the login response.
            }
            return res.data;
        } catch (err) {
            console.error("Login Failed:", err.response?.data?.message || err.message);
            setLogin(false);
            return err.response?.data;
        } finally{
            setLoading(false);
        }
    };
    const logoutUser = async ()=>{
        try {
            // You'll need a backend logout endpoint that clears the cookie
            await __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('http://localhost:3000/api/logout', {}, {
                withCredentials: true
            });
            setLogin(false);
            setId('');
            setName('');
        } catch (err) {
            console.error("Logout Failed:", err);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            login,
            loginUser,
            logoutUser,
            loading,
            id,
            name,
            setId,
            setName
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/legal_web/context/LoginContext.jsx",
        lineNumber: 83,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(AuthProvider, "imvuPOtJrHEtK5U3R4QjUo1UekM=");
_c = AuthProvider;
const useAuth = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (!context) {
    // console.log('use context inside the provider')
    }
    return context;
};
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/legal_web/context/PlansContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PlanProvider",
    ()=>PlanProvider,
    "usePlan",
    ()=>usePlan
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
const PlanContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const PlanProvider = ({ children })=>{
    _s();
    const [selectedPlan, setSelectedPlan] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isPlanLoaded, setIsPlanLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedRegions, setSelectedRegions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    // ✅ Load from localStorage only once
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PlanProvider.useEffect": ()=>{
            const stored = localStorage.getItem("selectedPlan");
            // console.log('stored',stored)
            if (stored) {
                setSelectedPlan(JSON.parse(stored));
            }
            setIsPlanLoaded(true);
        }
    }["PlanProvider.useEffect"], []);
    // ✅ Save to localStorage whenever plan changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PlanProvider.useEffect": ()=>{
            if (selectedPlan) {
                const safePlan = {
                    ...selectedPlan,
                    regions: Array.isArray(selectedPlan.regions) ? selectedPlan.regions : []
                };
                localStorage.setItem("selectedPlan", JSON.stringify(safePlan));
            } else {
                localStorage.removeItem("selectedPlan");
            }
        }
    }["PlanProvider.useEffect"], [
        selectedPlan
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PlanContext.Provider, {
        value: {
            selectedPlan,
            setSelectedPlan,
            isPlanLoaded,
            selectedRegions,
            setSelectedRegions
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/legal_web/context/PlansContext.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(PlanProvider, "gciLt2m7O/X8703YB7yKCM2T9ec=");
_c = PlanProvider;
const usePlan = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(PlanContext);
    if (!context) {
        throw new Error("usePlan must be used within a PlanProvider");
    }
    return context;
};
_s1(usePlan, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "PlanProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/legal_web/components/IconsWrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LayoutVisibilityWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function LayoutVisibilityWrapper({ children }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    // 👇 You can adjust this condition for multiple routes
    const hideSideIcons = pathname === "/PersonalDashboard";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            children,
            !hideSideIcons && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden lg:block fixed left-0 bottom-10 transform -translate-y-1/2 flex flex-col space-y-4 pl-2 z-50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "https://www.facebook.com/61579231556644/",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "w-10 h-10 rounded-full bg-blue-200 flex items-center justify-center hover:bg-blue-400 transition-colors mb-2 ",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sr-only",
                                            children: "Facebook"
                                        }, void 0, false, {
                                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                            lineNumber: 24,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 24 24",
                                            "aria-hidden": "true",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                fillRule: "evenodd",
                                                d: "M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z",
                                                clipRule: "evenodd"
                                            }, void 0, false, {
                                                fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                                lineNumber: 26,
                                                columnNumber: 15
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                            lineNumber: 25,
                                            columnNumber: 13
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                    lineNumber: 20,
                                    columnNumber: 14
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "https://x.com/jplawsuvidha_in",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "w-10 h-10 rounded-full bg-blue-200 flex items-center justify-center hover:bg-blue-400 transition-colors mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sr-only",
                                            children: "Twitter"
                                        }, void 0, false, {
                                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                            lineNumber: 35,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "24",
                                            height: "24",
                                            fill: "black",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M19.782 3H23L14.877 10.67 24 21h-7.238l-5.67-6.38L4.8 21H1l9.706-8.91L0 3h7.407l5.1 5.748L19.782 3zm-2.17 16.125h2.005L6.25 4.74H4.117l13.495 14.385z"
                                            }, void 0, false, {
                                                fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                                lineNumber: 37,
                                                columnNumber: 15
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                            lineNumber: 36,
                                            columnNumber: 13
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                    lineNumber: 30,
                                    columnNumber: 14
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "https://www.linkedin.com/in/jplawsuvidha-undefined-79a211379/",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "w-10 h-10 rounded-full bg-blue-200 flex items-center justify-center hover:bg-blue-400 transition-colors",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sr-only",
                                            children: "LinkedIn"
                                        }, void 0, false, {
                                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                            lineNumber: 45,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 24 24",
                                            "aria-hidden": "true",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                fillRule: "evenodd",
                                                d: "M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z",
                                                clipRule: "evenodd"
                                            }, void 0, false, {
                                                fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                                lineNumber: 47,
                                                columnNumber: 15
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                            lineNumber: 46,
                                            columnNumber: 13
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                    lineNumber: 41,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                            lineNumber: 18,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                        lineNumber: 17,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "lg:block fixed bottom-3 left-3 transform -translate-y-1/2 flex flex-col  pl-0 z-50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "https://wa.me/918639930413?text=Hello%2C%20I%20want%20to%20know%20more%21",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "w-16 h-10 rounded-full bg-blue-200 flex items-center justify-center hover:bg-blue-400 transition-colors animate-whatsapp ",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "sr-only",
                                    children: "WhatsApp"
                                }, void 0, false, {
                                    fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                    lineNumber: 59,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    viewBox: "0 0 32 32",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "16",
                                            cy: "16",
                                            r: "16",
                                            fill: "#25D366"
                                        }, void 0, false, {
                                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                            lineNumber: 61,
                                            columnNumber: 3
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M16.0031 8C11.5848 8 8.00312 11.5817 8.00312 16C8.00312 17.4219 8.38438 18.7625 9.05625 19.9219L8 24L12.1906 22.9594C13.3094 23.5625 14.6125 23.9031 16.0031 23.9031C20.4219 23.9031 24.0031 20.3219 24.0031 15.9031C24.0031 11.4844 20.4219 8 16.0031 8ZM16.0031 9.5C19.5969 9.5 22.5031 12.4062 22.5031 16C22.5031 19.5938 19.5969 22.5 16.0031 22.5C14.7406 22.5 13.5594 22.1594 12.5469 21.5625L12.2844 21.4062L10.0469 22.0156L10.6719 19.8406L10.4969 19.5625C9.84375 18.5188 9.50312 17.2969 9.50312 16C9.50312 12.4062 12.4094 9.5 16.0031 9.5ZM13.3 12.25C13.1562 12.25 12.9094 12.3031 12.7031 12.5094C12.4969 12.7156 11.9 13.2844 11.9 14.4375C11.9 15.5906 12.7219 16.7031 12.8469 16.8656C12.9719 17.0281 14.4375 19.3781 16.7688 20.3656C18.7344 21.1938 19.1 21.0469 19.4969 21.0094C19.8938 20.9719 20.8625 20.3844 21.0688 19.7781C21.2719 19.1719 21.275 18.6562 21.2188 18.5594C21.1625 18.4625 21 18.4062 20.7563 18.2844C20.5125 18.1625 19.3625 17.5938 19.1375 17.5094C18.9125 17.425 18.75 17.3844 18.5875 17.6281C18.425 17.8719 17.9688 18.4062 17.825 18.5688C17.6813 18.7313 17.5375 18.7531 17.2938 18.6313C17.05 18.5094 16.2344 18.2344 15.2656 17.3719C14.5063 16.6969 13.9969 15.8625 13.8531 15.6188C13.7094 15.375 13.8375 15.2406 13.9594 15.1188C14.0688 15.0094 14.2031 14.8344 14.325 14.6906C14.4469 14.5469 14.4875 14.4469 14.5719 14.2844C14.6563 14.1219 14.6156 13.9781 14.5531 13.8563C14.4906 13.7344 13.9875 12.5813 13.7844 12.0969C13.5875 11.6344 13.3875 11.6969 13.2375 11.6906C13.0938 11.6844 12.9313 11.6844 12.7688 11.6844C12.6063 11.6844 12.3406 11.7469 12.1156 11.9906C11.8906 12.2344 11.2875 12.8031 11.2875 13.9563C11.2875 15.1094 12.1344 16.2219 12.2563 16.3844C12.3781 16.5469 13.9875 19.0969 16.5094 20.0969C18.4 20.8594 18.9156 20.6719 19.4656 20.6188C20.0156 20.5656 20.9406 20.1156 21.1438 19.6281C21.3469 19.1406 21.3469 18.7281 21.2844 18.6313C21.2219 18.5344 21.0594 18.4719 20.8156 18.35C20.5719 18.2281 19.4219 17.6594 19.1969 17.575C18.9719 17.4906 18.8094 17.45 18.6469 17.6938C18.4844 17.9375 18.0281 18.4719 17.8844 18.6344C17.7406 18.7969 17.5969 18.8188 17.3531 18.6969C17.1094 18.575 16.2938 18.3 15.325 17.4375C14.5656 16.7625 14.0563 15.9281 13.9125 15.6844C13.7688 15.4406 13.8969 15.3063 14.0188 15.1844C14.1281 15.075 14.2625 14.9 14.3844 14.7563C14.5063 14.6125 14.5469 14.5125 14.6313 14.35C14.7156 14.1875 14.675 14.0438 14.6125 13.9219C14.55 13.8 14.0469 12.6469 13.8438 12.1625C13.6469 11.7 13.4469 11.7625 13.2969 11.7563C13.1531 11.75 12.9906 11.75 12.8281 11.75C12.6656 11.75 12.4 11.8125 12.175 12.0563C11.95 12.3 11.3469 12.8688 11.3469 14.0219C11.3469 15.175 12.1938 16.2875 12.3156 16.45C12.4375 16.6125 14.0469 19.1625 16.5688 20.1625C18.4594 20.925 18.975 20.7375 19.525 20.6844C20.075 20.6313 21 20.1813 21.2031 19.6938C21.4063 19.2063 21.4063 18.7938 21.3438 18.6969C21.2813 18.6 21.1188 18.5375 20.875 18.4156C20.6313 18.2938 19.4813 17.725 19.2563 17.6406C19.0313 17.5563 18.8688 17.5156 18.7063 17.7594C18.5438 18.0031 18.0875 18.5375 17.9438 18.7C17.8 18.8625 17.6563 18.8844 17.4125 18.7625C17.1688 18.6406 16.3531 18.3656 15.3844 17.5031C14.625 16.8281 14.1156 15.9938 13.9719 15.75C13.8281 15.5063 13.9563 15.3719 14.0781 15.25C14.1875 15.1406 14.3219 14.9656 14.4438 14.8219C14.5656 14.6781 14.6063 14.5781 14.6906 14.4156C14.775 14.2531 14.7344 14.1094 14.6719 13.9875C14.6094 13.8656 14.1063 12.7125 13.9031 12.2281C13.7063 11.7656 13.5063 11.8281 13.3563 11.8219C13.2125 11.8156 13.05 11.8156 12.8875 11.8156C12.725 11.8156 12.4594 11.8781 12.2344 12.1219C12.0094 12.3656 11.4063 12.9344 11.4063 14.0875C11.4063 15.2406 12.2531 16.3531 12.375 16.5156C12.4969 16.6781 14.1063 19.2281 16.6281 20.2281C18.5188 20.9906 19.0344 20.8031 19.5844 20.75C20.1344 20.6969 21.0594 20.2469 21.2625 19.7594C21.4656 19.2719 21.4656 18.8594 21.4031 18.7625C21.3406 18.6656 21.1781 18.6031 20.9344 18.4813C20.6906 18.3594 19.5406 17.7906 19.3156 17.7063C19.0906 17.6219 18.9281 17.5813 18.7656 17.825C18.6031 18.0688 18.1469 18.6031 18.0031 18.7656C17.8594 18.9281 17.7156 18.95 17.4719 18.8281C17.2281 18.7063 16.4125 18.4313 15.4438 17.5688C14.6844 16.8938 14.175 16.0594 14.0313 15.8156C13.8875 15.5719 14.0156 15.4375 14.1375 15.3156C14.2469 15.2063 14.3813 15.0313 14.5031 14.8875C14.625 14.7438 14.6656 14.6438 14.75 14.4813C14.8344 14.3188 14.7938 14.175 14.7313 14.0531C14.6688 13.9313 14.1656 12.7781 13.9625 12.2938C13.7656 11.8313 13.5656 11.8938 13.4156 11.8875C13.2719 11.8813 13.1094 11.8813 12.9469 11.8813L13.3 12.25Z",
                                            fill: "white"
                                        }, void 0, false, {
                                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                            lineNumber: 62,
                                            columnNumber: 3
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                                    lineNumber: 60,
                                    columnNumber: 12
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                            lineNumber: 55,
                            columnNumber: 10
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/legal_web/components/IconsWrapper.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true);
}
_s(LayoutVisibilityWrapper, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = LayoutVisibilityWrapper;
var _c;
__turbopack_context__.k.register(_c, "LayoutVisibilityWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/legal_web/i18n.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$i18next$2f$dist$2f$esm$2f$i18next$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/i18next/dist/esm/i18next.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/legal_web/node_modules/react-i18next/dist/es/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$initReactI18next$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/react-i18next/dist/es/initReactI18next.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$i18next$2d$resources$2d$to$2d$backend$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/i18next-resources-to-backend/dist/esm/index.js [app-client] (ecmascript)");
'use client';
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$i18next$2f$dist$2f$esm$2f$i18next$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].use(__TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$react$2d$i18next$2f$dist$2f$es$2f$initReactI18next$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initReactI18next"]).use((0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$i18next$2d$resources$2d$to$2d$backend$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((language, namespace)=>__turbopack_context__.f({
        "@/public/locales/en/Faq.json": {
            id: ()=>"[project]/legal_web/public/locales/en/Faq.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/en/Faq.json (json, async loader)")
        },
        "@/public/locales/en/Legal_enterprise.json": {
            id: ()=>"[project]/legal_web/public/locales/en/Legal_enterprise.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/en/Legal_enterprise.json (json, async loader)")
        },
        "@/public/locales/en/Legalrep.json": {
            id: ()=>"[project]/legal_web/public/locales/en/Legalrep.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/en/Legalrep.json (json, async loader)")
        },
        "@/public/locales/en/expertise.json": {
            id: ()=>"[project]/legal_web/public/locales/en/expertise.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/en/expertise.json (json, async loader)")
        },
        "@/public/locales/en/services.json": {
            id: ()=>"[project]/legal_web/public/locales/en/services.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/en/services.json (json, async loader)")
        },
        "@/public/locales/te/Faq.json": {
            id: ()=>"[project]/legal_web/public/locales/te/Faq.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/te/Faq.json (json, async loader)")
        },
        "@/public/locales/te/Legal_enterprise.json": {
            id: ()=>"[project]/legal_web/public/locales/te/Legal_enterprise.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/te/Legal_enterprise.json (json, async loader)")
        },
        "@/public/locales/te/Legalrep.json": {
            id: ()=>"[project]/legal_web/public/locales/te/Legalrep.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/te/Legalrep.json (json, async loader)")
        },
        "@/public/locales/te/expertise.json": {
            id: ()=>"[project]/legal_web/public/locales/te/expertise.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/te/expertise.json (json, async loader)")
        },
        "@/public/locales/te/services.json": {
            id: ()=>"[project]/legal_web/public/locales/te/services.json (json, async loader)",
            module: ()=>__turbopack_context__.A("[project]/legal_web/public/locales/te/services.json (json, async loader)")
        }
    }).import(`@/public/locales/${language}/${namespace}.json`))).init({
    fallbackLng: 'te',
    debug: false,
    ns: [
        'services',
        'expertise',
        'faq'
    ],
    defaultNS: 'services',
    interpolation: {
        escapeValue: false
    }
});
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$i18next$2f$dist$2f$esm$2f$i18next$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/legal_web/components/ScrollToTop.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/legal_web/node_modules/next/navigation.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const ScrollToTop = ()=>{
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    // console.log(pathname)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ScrollToTop.useEffect": ()=>{
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }
    }["ScrollToTop.useEffect"], [
        pathname
    ]);
    return null;
};
_s(ScrollToTop, "V/ldUoOTYUs0Cb2F6bbxKSn7KxI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$legal_web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = ScrollToTop;
const __TURBOPACK__default__export__ = ScrollToTop;
var _c;
__turbopack_context__.k.register(_c, "ScrollToTop");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=legal_web_6c69c9f0._.js.map