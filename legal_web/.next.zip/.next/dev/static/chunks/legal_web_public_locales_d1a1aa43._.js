(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/legal_web/public/locales/en/Faq.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_en_Faq_json_d649bc27._.js",
  "static/chunks/legal_web_public_locales_en_Faq_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/en/Faq.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/en/Legal_enterprise.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_en_Legal_enterprise_json_246a9c83._.js",
  "static/chunks/legal_web_public_locales_en_Legal_enterprise_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/en/Legal_enterprise.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/en/Legalrep.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_en_Legalrep_json_bf3bc230._.js",
  "static/chunks/legal_web_public_locales_en_Legalrep_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/en/Legalrep.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/en/expertise.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_en_expertise_json_f6e1911e._.js",
  "static/chunks/legal_web_public_locales_en_expertise_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/en/expertise.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/en/services.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_en_services_json_5f7749f1._.js",
  "static/chunks/legal_web_public_locales_en_services_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/en/services.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/te/Faq.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_te_Faq_json_3fa0a3e2._.js",
  "static/chunks/legal_web_public_locales_te_Faq_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/te/Faq.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/te/Legal_enterprise.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_te_Legal_enterprise_json_2367f6ba._.js",
  "static/chunks/legal_web_public_locales_te_Legal_enterprise_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/te/Legal_enterprise.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/te/Legalrep.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_te_Legalrep_json_e7b16042._.js",
  "static/chunks/legal_web_public_locales_te_Legalrep_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/te/Legalrep.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/te/expertise.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_te_expertise_json_03401264._.js",
  "static/chunks/legal_web_public_locales_te_expertise_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/te/expertise.json (json)");
    });
});
}),
"[project]/legal_web/public/locales/te/services.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/legal_web_public_locales_te_services_json_98cf757a._.js",
  "static/chunks/legal_web_public_locales_te_services_json_f41118cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/legal_web/public/locales/te/services.json (json)");
    });
});
}),
]);