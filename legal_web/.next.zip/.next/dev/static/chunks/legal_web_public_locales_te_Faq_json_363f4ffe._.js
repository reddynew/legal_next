(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/legal_web_public_locales_te_Faq_json_3fa0a3e2._.js"
],
    source: "dynamic"
});
