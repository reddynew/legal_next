(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/08594_a8e1bbf2._.js",
  "static/chunks/legal_web_3767949c._.js"
],
    source: "dynamic"
});
