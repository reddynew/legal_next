(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/legal_web_public_locales_te_Legal_enterprise_json_2367f6ba._.js"
],
    source: "dynamic"
});
