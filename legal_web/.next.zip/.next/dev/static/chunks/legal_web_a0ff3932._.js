(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8c046bb4._.js",
  "static/chunks/08594_next_dist_compiled_react-dom_81378d89._.js",
  "static/chunks/08594_next_dist_compiled_react-server-dom-turbopack_03e11fbd._.js",
  "static/chunks/08594_next_dist_compiled_next-devtools_index_43e3090a.js",
  "static/chunks/08594_next_dist_compiled_72d09ec6._.js",
  "static/chunks/08594_next_dist_client_4da61896._.js",
  "static/chunks/08594_next_dist_89660b38._.js",
  "static/chunks/08594_@swc_helpers_cjs_e99ffcc7._.js"
],
    source: "entry"
});
