(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/legal_web_23bc17fe._.js",
  "static/chunks/08594_tailwind-merge_dist_bundle-mjs_mjs_0dc6cc60._.js",
  "static/chunks/08594_lucide-react_dist_esm_icons_index_699ace51.js",
  "static/chunks/08594_lucide-react_dist_esm_icons_5a860044._.js",
  "static/chunks/08594_lucide-react_dist_esm_lucide-react_9d3bd4a7.js",
  "static/chunks/08594_lucide-react_dist_esm_ff3f3fc2._.js",
  "static/chunks/08594_swiper_742fdc9b._.js",
  "static/chunks/08594_829cc306._.js",
  "static/chunks/08594_swiper_92724abb._.css"
],
    source: "dynamic"
});
