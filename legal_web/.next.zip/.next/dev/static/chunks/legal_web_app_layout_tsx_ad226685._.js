(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__cbefa4a0._.css",
  "static/chunks/legal_web_public_locales_d1a1aa43._.js",
  "static/chunks/08594_059b37ab._.js",
  "static/chunks/legal_web_494de77a._.js"
],
    source: "dynamic"
});
