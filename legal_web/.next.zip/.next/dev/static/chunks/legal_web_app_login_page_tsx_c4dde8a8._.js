(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/legal_web_22964413._.js",
  "static/chunks/08594_95b33dcc._.js"
],
    source: "dynamic"
});
