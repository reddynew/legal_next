(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/legal_web_public_locales_en_Legalrep_json_bf3bc230._.js"
],
    source: "dynamic"
});
