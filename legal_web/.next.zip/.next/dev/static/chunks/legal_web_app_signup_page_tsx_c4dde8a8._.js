(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/legal_web_4586f400._.js",
  "static/chunks/08594_9197a57f._.js"
],
    source: "dynamic"
});
